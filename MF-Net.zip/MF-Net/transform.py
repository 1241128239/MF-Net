"""

Author: Honggu Liu
"""
from torchvision import transforms

mesonet_data_transforms = {
    'train': transforms.Compose([  # 相关函数、代码块进行整合
        # transforms.RandomResizedCrop(224),
        # transforms.RandomHorizontalFlip(),
        # transforms.ToTensor(),
        # transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
        transforms.Resize((256, 256)),
        transforms.ToTensor(),  # 能够把灰度范围从0-255变换到0-1之间
        transforms.Normalize([0.5]*3, [0.5]*3)  # 最大最小值由原来的0，1变为-1，1，先将输入归一化到(0,1)，再使用公式"(x-mean)/std"，将每个元素分布到(-1,1)
    ]),
    'val': transforms.Compose([
        # transforms.Resize((224, 224)),  # cannot 224, must (224, 224)
        # transforms.ToTensor(),
        # transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
        transforms.Resize((256, 256)),
        transforms.ToTensor(),
        transforms.Normalize([0.5] * 3, [0.5] * 3)
    ]),
    'test': transforms.Compose([
        transforms.Resize((256, 256)),
        transforms.ToTensor(),
        transforms.Normalize([0.5] * 3, [0.5] * 3)
    ]),
}
